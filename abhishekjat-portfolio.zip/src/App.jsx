import React from 'react'
import { motion } from 'framer-motion'

function App() {
  return (
    <div className="container">
      <motion.h1
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.8 }}
      >
        Abhishek Jat
      </motion.h1>
      <motion.h2
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        Psycho Da Goat 🐐
      </motion.h2>
      <p>Welcome to my portfolio website!</p>
      <div className="links">
        <a href="https://github.com/abhishekjaat1" target="_blank">GitHub</a>
        <a href="https://instagram.com/" target="_blank">Instagram</a>
      </div>
    </div>
  )
}

export default App